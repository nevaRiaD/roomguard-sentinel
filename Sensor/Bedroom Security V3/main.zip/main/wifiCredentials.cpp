#include "wifiCredentials.h"

const char* ssid = nullptr;
const char* password = nullptr;

void setWiFiCredentials(const char* ssid_value, const char* password_value) {
    // input WiFi ssid and password below
    ssid = "PINOIBLUE";
    password = "man1ya2kis3ka456";
}